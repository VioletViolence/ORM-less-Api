﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using ORM_less_Web_API.Model;
using System.Data;

namespace ORM_less_Web_API.Controllers
{
    [Route("/users")]
    [ApiController]
    public class UsersController : Controller
    {

        String lbFound;

        [Produces("application/json")]
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-MCS2FRU;Initial Catalog=Users;Integrated Security=True"))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Users", conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                Dictionary<string, object> row;
                foreach (DataRow dr in dt.Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (DataColumn col in dt.Columns)
                    {

                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }
                conn.Close();

                return new OkObjectResult(rows);
            }

        }
    }
}